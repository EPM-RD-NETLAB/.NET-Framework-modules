﻿namespace DocumentationComments
{
    /// <summary>
    /// Provides simple calculator functionality. 
    /// </summary>
    public static class Calculator
    {
        /// <summary>
        /// Adds the integer numbers <paramref name="a"/>
        /// and <paramref name="b"/> together.
        /// </summary>
        /// <param name="a">First integer term to add.</param>
        /// <param name="b">Second integer term to add.</param>
        /// <returns>
        /// Sum of the integer numbers <paramref name="a"/>
        /// and <paramref name="b"/>
        /// </returns>
        /// <exception cref="System.OverflowException">
        /// Thrown when the computed sum does not fit in the precision of 
        /// System.Int32.
        /// </exception>
        /// <example>
        /// <code>int res = Add(1, 2); // produces value 3
        /// </code>
        /// </example>
        public static int Add(int a, int b) => checked(a + b);
    }
}
