﻿using TDD.Demo;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;

namespace TDD.Demo.Tests
{
    [TestClass()]
    public class SomeClassTest
    {
        [TestMethod]
        public void SameMethodAllPositiveNumbers()
        {
            var a = new int[] { 1, 2, 3, 4, 5 };

            int expected = 15;

            int actual = SomeClass.SomeMethod(a);

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void SameMethodNegativeNumbersExist()
        {
            var a = new int[] { 1, 2, 3, 4, 5, -15 };

            int expected = 0;

            int actual = SomeClass.SomeMethod(a);

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void SameMethodEmptyArray()
        {
            var a = new int[] { };

            int expected = 0;

            int actual = SomeClass.SomeMethod(a);

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void SameMethodNullReference()
        {
            int[] a = null;

            int expected = 0;

            int actual = SomeClass.SomeMethod(a);

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        [ExpectedException(typeof(OverflowException))]
        public void SameMethodOverflowException()
        {
            int[] a = { 1, int.MaxValue };
            int actual = SomeClass.SomeMethod(a);
        }
    }
}
