﻿using System;

namespace SomeClass
{
    public class ClassForTest
    {
        public static int DoCalculations(string s)
        {
            int number;
            if (int.TryParse(s, out number))
            {
                return (int) Math.Pow(number, 3);
            }
            else
            {
                throw new FormatException("It's not a integer number.");
            }
        }
    }
}