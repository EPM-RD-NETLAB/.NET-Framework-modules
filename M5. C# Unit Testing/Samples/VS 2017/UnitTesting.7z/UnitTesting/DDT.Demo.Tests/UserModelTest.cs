﻿using DDT.Demo;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;

namespace DDT.Demo.Tests
{
    [TestClass()]
    public class UserModelTest
    {
        public TestContext TestContext { get; set; }

        [DataSource(
            "Microsoft.VisualStudio.TestTools.DataSource.XML",
            "|DataDirectory|\\Users.xml",
            "TestCase",
            DataAccessMethod.Sequential)]
        [DeploymentItem("DDT.Demo.Tests\\Users.xml")]
        [TestMethod]
        public void TestMethod1()
        {
            var userModel = new UserModel
            {
                FirstName = Convert.ToString(TestContext.DataRow["FirstName"]),
                LastName = Convert.ToString(TestContext.DataRow["LastName"])
            };

            var expected = Convert.ToString(TestContext.DataRow["ExpectedResult"]);

            var actual = userModel.ToDisplayString();

            Assert.AreEqual(expected, actual);
        }
    }
}
