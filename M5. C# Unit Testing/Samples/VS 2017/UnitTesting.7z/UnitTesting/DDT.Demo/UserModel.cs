﻿using System.Linq;

namespace DDT.Demo
{
    public class UserModel
    {
        public string FirstName { get; set; }

        public string LastName { get; set; }

        public string ToDisplayString()
        {
            var users = new string[]
                {
                    this.FirstName,
                    this.LastName
                };

            return string.Join(" ", users);//.Where(x => !string.IsNullOrEmpty(x)));
        }
    }
}
