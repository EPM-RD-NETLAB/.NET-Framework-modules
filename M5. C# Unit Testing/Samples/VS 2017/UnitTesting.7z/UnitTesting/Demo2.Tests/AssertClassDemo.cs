﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Demo2.Tests
{
    [TestClass]
    public class AssertClassDemo
    {
        [TestMethod]
        public void AreEqualTest1()
        {
            var expected = 0.2f;
            var actual = 0.2;

            Assert.AreEqual(expected, actual,0.0000001);
        }

        [TestMethod]
        public void AreEqualTest2()
        {
            var expected = 1;
            var actual = 1;

            Assert.AreEqual(expected, actual, "{0} <> {1}", expected, actual);
        }

        [TestMethod]
        public void AreSameTest()
        {
            var expected = new Object();
            var actual = expected;

            Assert.AreSame(expected, actual);
        }

        [TestMethod]
        public void IsNullTest()
        {
            object value = null;

            Assert.IsNull(value);
        }

        [TestMethod]
        public void IsTrueTest()
        {
            var s1 = "1";
            var s2 = "2";

            Assert.IsTrue(String.CompareOrdinal(s1, s2) < 0);
        }
    }
}
