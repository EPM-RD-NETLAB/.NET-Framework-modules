﻿using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Demo2.Tests
{
    [TestClass]
    public class InconclusiveDemo
    {
        [TestMethod]
        public void Test1()
        {
            Assert.Inconclusive();
        }
    }
}
