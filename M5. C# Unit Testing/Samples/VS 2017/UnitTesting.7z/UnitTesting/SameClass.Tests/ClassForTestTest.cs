﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;

namespace SomeClass.Tests
{
    /// <summary>
    ///This is a test class for ClassForTestTest and is intended
    ///to contain all ClassForTestTest Unit Tests
    ///</summary>
    [TestClass()]
    public class ClassForTestTest
    {
        /// <summary>
        ///A test for DoCalculations
        ///</summary>
        [TestMethod()]
        public void DoCalculationsTest()
        {
            string s = "-3"; // TODO: Initialize to an appropriate value

            int actual = ClassForTest.DoCalculations(s);

            int expected = -27; // TODO: Initialize to an appropriate value
            Assert.AreEqual(expected, actual, "{0} != {1}", expected, actual);

            //Assert.Inconclusive("Verify the correctness of this test method.");
        }

        [TestMethod()]
        [ExpectedException(typeof(FormatException))]
        public void DoCalculationsTestExeption()
        {
            string s = "abc"; // TODO: Initialize to an appropriate value
            //int expected = 27; // TODO: Initialize to an appropriate value
            int actual = ClassForTest.DoCalculations(s);
            //Assert.AreEqual(expected, actual);
            //Assert.Inconclusive("Verify the correctness of this test method.");
        }
    }
}