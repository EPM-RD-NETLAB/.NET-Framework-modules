﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Demo1.Tests
{
   public static class ExceptionAssert
    {
        public static void ThrowsInstanceOf<T>(Action action)
        {
            try
            {
                action();
            }
            catch (Exception xcp)
            {
                if (xcp is T)
                {
                    return;
                }

                throw new AssertFailedException(
                    String.Format(
                        "Test action threw exception {0}, but exception {1} was expected.",
                        xcp.GetType().FullName,
                        typeof(T).FullName));
            }

            throw new AssertFailedException(
                String.Format(
                    "Test action did not throw expected exception {0}.",
                    typeof(T).FullName));
        }
    }

    [TestClass]
    public class UnitTest2
    {
        [TestMethod]
        public void GetColumnIndexErrorTest()
        {
            ExceptionAssert.ThrowsInstanceOf<ArgumentException>(
                () => XlCellRefUtility.GetColumnIndex(null));
        }
    }
}
