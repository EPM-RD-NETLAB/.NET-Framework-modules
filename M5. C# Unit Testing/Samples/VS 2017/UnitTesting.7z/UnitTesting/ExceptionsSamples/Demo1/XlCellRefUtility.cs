﻿using System;

namespace Demo1
{
    public class XlCellRefUtility
    {
        public static int GetColumnIndex(string value)
        {
            if (String.IsNullOrEmpty(value))
            {
                throw new ArgumentException();
            }

            int result = 0;

            for (int i = 0; i < value.Length; i++)
            {
                var c = (int)value[i];

                if (c < (int)'A' || c > (int)'Z')
                {
                    break;
                }

                result = result * 26 + (c - (int)'A' + 1);
            }

            return result;
        }
    }
}
