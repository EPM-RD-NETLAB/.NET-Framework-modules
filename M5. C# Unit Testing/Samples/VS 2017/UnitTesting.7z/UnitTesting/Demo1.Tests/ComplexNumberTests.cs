﻿using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Demo1.Tests
{
    [TestClass]
    public class ComplexNumberTests
    {
        [TestMethod]
        public void ConstructorTest()
        {
            var a = new ComplexNumber(1.0, 2.0);

            Assert.AreEqual(a.X, 1.0);
            Assert.AreEqual(a.Y, 2.0);
        }

        [TestMethod]
        public void AddOperatorTest()
        {
            var a = new ComplexNumber(1.0, 2.0);
            var b = new ComplexNumber(3.0, 4.0);

            var result = a + b;

            Assert.AreEqual(4.0, result.X, 1E-3);
            Assert.AreEqual(6.0, result.Y, 1E-3);
        }
    }
}