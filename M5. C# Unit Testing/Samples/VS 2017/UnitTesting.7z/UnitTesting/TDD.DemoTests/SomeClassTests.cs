﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
namespace TDD.Demo.Tests
{
    [TestClass()]
    public class SomeClassTests
    {
        [TestMethod()]
        public void SomeMethodTest()
        {

        }
    }
}
