﻿using Demo3;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;

namespace Demo3.Tests
{
    
    [TestClass()]
    public class TestClassTest
    {
        [AssemblyInitialize]
        public static void AssemblyInitialize(TestContext context)
        {
            System.Diagnostics.Trace.WriteLine("***** AssemblyInitialize()");
        }

        [AssemblyCleanup]
        public static void AssemblyCleanup()
        {
            System.Diagnostics.Debug.WriteLine("***** AssemblyCleanup()");
        }

        [ClassInitialize]
        public static void ClassInitialize(TestContext context)
        {
            System.Diagnostics.Debug.WriteLine("**** ClassInitialize()");
        }

        [ClassCleanup]
        public static void ClassCleanup()
        {
            System.Diagnostics.Debug.WriteLine("**** ClassCleanup()");
        }

        [TestInitialize]
        public void TestInitialize()
        {
            System.Diagnostics.Debug.WriteLine("*** TestInitialize()");
        }

        [TestCleanup]
        public void TestCleanup()
        {
            System.Diagnostics.Debug.WriteLine("*** TestCleanup()");
        }

        [TestMethod]
        public void TestMethod1()
        {
            System.Diagnostics.Debug.WriteLine("** TestMethod1()");
        }

        [TestMethod]
        public void TestMethod2()
        {
            System.Diagnostics.Debug.WriteLine("** TestMethod1()");
        }
    }
}
