﻿using System.Text.RegularExpressions;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Demo2.Tests
{
    [TestClass]
    public class StringAssertDemo
    {
        [TestMethod]
        public void ContainsTest()
        {
            var value = "One Two Three";

            StringAssert.Contains(value, "Two");
        }

        [TestMethod]
        public void StartsWithTest()
        {
            var value = "One Two Three";

            StringAssert.StartsWith(value, "One");
        }

        [TestMethod]
        public void EndsWithTest()
        {
            var value = "One Two Three";

            StringAssert.EndsWith(value, "Three");
        }

        [TestMethod]
        public void MathesTest()
        {
            var value = "123";

            StringAssert.Matches(value, new Regex(@"\d+"));
        }
    }
}
