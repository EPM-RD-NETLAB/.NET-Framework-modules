﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Demo2.Tests
{
    [TestClass]
    public class AssertFailedExceptionDemo
    {
        [TestMethod]
        public void Test1()
        {
            try
            {
                Assert.AreEqual(1, 2);
            }
            catch (Exception xcp)
            {
                System.Diagnostics.Debug.Write(xcp.ToString());
            }
        }
    }
}
