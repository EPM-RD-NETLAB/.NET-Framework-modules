﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Demo2.Tests
{
    [TestClass]
    public class CollectionAssertDemo
    {
        [TestMethod]
        public void AreEqualTest1()
        {
            var expected = new string[] { "One", "Two", "Three" };
            var actual = new string[] { "One", "Two", "Three" };

            CollectionAssert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void AreEqualTest2()
        {
            var expected = new string[] { "One", "Two", "Three" };
            var actual = new string[] { "ONE", "TWO", "THREE" };

            CollectionAssert.AreEqual(expected, actual, StringComparer.OrdinalIgnoreCase);
        }

        [TestMethod]
        public void AreEquivalentTest()
        {
            var expected = new string[] { "One", "Two", "Three" };
            var actual = new string[] { "Three", "Two", "One" };

            CollectionAssert.AreEquivalent(expected, actual);
        }

        [TestMethod]
        public void AllItemsAreUniqueTest()
        {
            var collection = new string[] { "One", "Two", "Three" };

            CollectionAssert.AllItemsAreUnique(collection);
        }

        [TestMethod]
        public void ContainsTest()
        {
            var collection = new string[] { "One", "Two", "Three" };

            CollectionAssert.Contains(collection, "One");
        }

        [TestMethod]
        public void IsSubsetOfTest()
        {
            var collection = new string[] { "One", "Two", "Three" };
            var subset = new string[] { "One", "Two" };

            CollectionAssert.IsSubsetOf(subset, collection);
        }
    }
}
