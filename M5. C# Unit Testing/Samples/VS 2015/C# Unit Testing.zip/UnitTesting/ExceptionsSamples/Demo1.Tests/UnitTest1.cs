﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Demo1.Tests
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void GetColumnIndexErrorTest()
        {
            XlCellRefUtility.GetColumnIndex(null);
        }
    }
}
