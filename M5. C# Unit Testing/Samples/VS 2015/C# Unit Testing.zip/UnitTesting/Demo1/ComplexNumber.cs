﻿namespace Demo1
{
    public class ComplexNumber
    {
        public ComplexNumber(double x, double y)
        {
            this.X = x;
            this.Y = y;
        }

        public double X { get; set; }

        public double Y { get; set; }

        public static ComplexNumber operator +(ComplexNumber a, ComplexNumber b)
        {
            return new ComplexNumber(a.X + b.X, a.Y + b.Y);
        }
    }
}
