﻿namespace TDD.Demo
{
    public class SomeClass
    {
        public static int SomeMethod(int[] a)
        {
            if (a == null || a.Length == 0)
            {
                return 0;
            }
            int sum = 0;

            checked
            {
                for (int i = 0; i < a.Length; i++)
                {
                    sum += a[i];
                }
            }
            return sum;
        }
    }
}
