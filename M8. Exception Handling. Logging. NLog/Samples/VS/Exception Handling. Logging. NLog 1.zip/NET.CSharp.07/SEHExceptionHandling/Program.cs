﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Diagnostics;

namespace SEHExceptionHandling
{
    public class Program
    {
        static void Main(string[] args)
        {
            try
            {
                FormatDataForDisplay();
            }
            catch (Exception e)
            {
                Debug.WriteLine("1. " + e.Message);
                Debug.WriteLine("2. " + e.Source);
                Debug.WriteLine("3. " + e.TargetSite);
                Debug.WriteLine("4. " + e.StackTrace);
                if (e.InnerException != null)
                {
                    Debug.WriteLine("5 inner exception: " + e.InnerException.StackTrace);
                }
            }
            finally
            {
                Debug.WriteLine("Bock finally in main works!");
            }
        }

        #region Function A

        static void FormatDataForDisplay()
        {
            try
            {
                ProcessData();
            }
            catch (Exception ex)
            {
                Debug.WriteLine("FormatDataForDisplay");
                Debug.WriteLine(ex.StackTrace);
                throw new Exception("All bad!", ex); ;
                //throw ex;//CLR считает, что исключение возникло здесь
            }
            finally 
            {
                Debug.WriteLine("FormatDataForDisplay block finally"); 
            }
        }
        #endregion

        #region Function B
        static void ProcessData()
        {
            try
            {
                GetFile();
            }
            catch (Exception ex)
            {
                Debug.WriteLine("ProcessData");
                Debug.WriteLine(ex.StackTrace);
                throw; //CLR не меняет информацию о начальной точке исключения
            }
            finally
            {
                Debug.WriteLine("ProcessData block finally");
            }
        }
        #endregion

        #region Function C
        static void GetFile()
        {
            File.Open("text.txt",FileMode.Open);
            throw new StackOverflowException();//IOException("Data File Data.txt was not found");
        }
        #endregion
    }
}