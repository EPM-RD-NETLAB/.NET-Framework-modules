﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using NLog;

//NuGet – это замечательный инструмент, позволяющий разработчику легко управлять 
//библиотеками в проектах любого типа

//Основной задачей NuGet является упрощение процесса установки сторонних библиотек.
//Он берет на себя все шаги этого процесса, в том числе:

// - поиск библиотеки;
// - загрузка необходимого для установки пакета;
// - проверка его хэш-значения на соответствие с заданным сервером (проверка целостности);
// - распаковка файлов библиотеки в нужное место;
// - добавление ссылок (reference) на её сборки в проект;
// - модификацию файлов конфигурации (web.config, app.config) при необходимости.

namespace ConsoleApplication1
{
    class Program
    {
        private static readonly Logger logger = LogManager.GetCurrentClassLogger();

        static void Main(string[] args)
        {
            try
            {
                throw new FileNotFoundException("File not found!");
            }
            catch (Exception e)
            {
                logger.Info("Unhandled exception:");
                logger.Info(e.Message);
                logger.Error(e.StackTrace);
            }
            Console.ReadKey();
        }
    }
}
