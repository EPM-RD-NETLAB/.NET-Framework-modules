﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;
//http://habrahabr.ru/post/253105/
//http://www.programmersforum.ru/showthread.php?t=187283
//http://programmersclub.ru/assembler/
namespace Sample3
{
    public class Employee : IComparable, IDisposable, ICloneable
    {
        private int _id;
        private string _name;
        public static CompanyPolicy _policy;
        public virtual void Work() { }
        public void TakeVacation(int days) { }
        public static void SetCompanyPolicy(CompanyPolicy policy)
        {
            _policy = policy;
        }

        public int CompareTo(object obj)
        {
            return 1;
        }

        public void Dispose() { }

        public virtual object Clone()
        {
            throw new NotImplementedException();
        }
    }
    class Manager : Employee, ISerializable
    {
        public sealed override void Work()
        {
            //TODO
        }

        #region Implementation of ISerializable

        public void GetObjectData(SerializationInfo info, StreamingContext context)
        {
            throw new NotImplementedException();
        }

        #endregion
    }

    struct Point
    {
        public double x, y;
    }
    class Program
    {
        static void Main(string[] args)
        {
            Point p = default(Point);
            p.ToString();
            p.GetHashCode();
            Console.ReadKey();
            Employee employee = new Employee();
            Employee.SetCompanyPolicy(CompanyPolicy.One);
            employee.TakeVacation(12);
            employee.Work();
            Employee.SetCompanyPolicy(CompanyPolicy.One);
            employee.Dispose();
            ((IComparable)employee).CompareTo(employee);
            IDisposable ir = employee;
            ir.Dispose();
            Employee empl = new Manager();
            empl.Work();
            empl.TakeVacation(11);
            employee.Clone();
        }
    }

    public enum CompanyPolicy
    {
        One,
        Two
    }
}
