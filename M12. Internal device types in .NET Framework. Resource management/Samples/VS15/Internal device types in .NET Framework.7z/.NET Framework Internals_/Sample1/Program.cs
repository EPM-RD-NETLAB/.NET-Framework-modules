﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//https://msdn.microsoft.com/ru-ru/library/bb190764(v=vs.110).aspx <-sos.dll

namespace Sample1
{
    class SomeClass
    {
        private readonly byte[] _largeObj;
        public SomeClass(int size)
        {
            _largeObj = new byte[size];
        }
    }

    class SomeProgram
    {
        static void Main(string[] args)
        {
            SomeClass obj = Create(84930, 10, 15, 20, 25);
        }
        private static SomeClass Create(int size1, int size2, int size3, int size4, int size5)
        {
            int objSize = size1 + size2 + size3 + size4 + size5;
            var obj = new SomeClass(objSize);
            return obj;
        }
    }
}

//SRV*C:\Symbols*http://msdl.microsoft.com/download/symbols
//.loadby sos clr
//!DumpDomain
//!DumpHeap
//!DumpHeap -type Sample1.SomeClass
//!DumpClass 00f617ec<-EEClassAdress
//!DumpObj 00f617ec
//http://blogs.msdn.com/b/alejacma/archive/2009/08/13/managed-debugging-with-windbg-managed-heap-part-1.aspx
//!EEVersion //Workstation mode
//!EEHeap -gc
//!FinalizeQueue