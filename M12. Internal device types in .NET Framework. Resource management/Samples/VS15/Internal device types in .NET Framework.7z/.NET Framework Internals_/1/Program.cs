﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
//http://www.codeproject.com/Articles/23589/Get-Started-Debugging-Memory-Related-Issues-in-Net
//https://support.microsoft.com/ru-ru/kb/311503
//Чтобы настроить WinDBG на использование Microsoft Symbol Server 
//в разделе File:Symbol File Path  устанавливаем путь 
//SRV*C:\Symbols*http://msdl.microsoft.com/download/symbols

namespace _1
{
    public class CompanyPolicy
    {
    }
    public class Employee
    {
        private int id;
        private string name;
        private static CompanyPolicy policy;
        public override string ToString()
        {
            return name;
        }
        public virtual void Work()
        {
            Console.WriteLine("Bla-bla...");
        }
        public void TakeVacation(int days)
        {
            Console.WriteLine("Bla-bla...");
        }
        public static void SetCompanyPolicy()
        {
            
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Employee.SetCompanyPolicy();
            Employee.Equals(new Employee(), new Employee());
            var employee = new Employee();
            int hash = employee.GetHashCode();
            employee.TakeVacation(12);
            employee.ToString();
            employee.Work();
        }
    }
}
//SRV*C:\Symbols*http://msdl.microsoft.com/download/symbols
//.loadby sos clr
//!DumpDomain
//!DumpHeap
//
