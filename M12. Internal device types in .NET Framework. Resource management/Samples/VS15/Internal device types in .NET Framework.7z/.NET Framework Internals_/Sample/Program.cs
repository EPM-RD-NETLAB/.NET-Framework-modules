﻿namespace Sample
{
    using System;

    public interface IInterfaceOne
    {
        void MethodOne();
        void MethodTwo();
    }

    public interface IInterfaceTwo
    {
        void MethodTwo();
        void MethodThree();
    }

    public interface IInterfaceThree
    {
        void MethodThree();
    }
    internal class CustomClass : IInterfaceOne, IInterfaceTwo, IInterfaceThree
    {
        public static string str = "CustomString";
        public static uint ui = 0xAAAAAAAA;

        public override string ToString()
        {
            return "Override method works!";
        }

        public override bool Equals(object obj)
        {
            return true;
        }

        public void MethodOne()
        {
            //Console.WriteLine("Method1");
        }

        void IInterfaceOne.MethodTwo()
        {
            //Console.WriteLine("Method2");
        }
    
        void IInterfaceTwo.MethodTwo()
        {
            //Console.WriteLine("Method2");
        }
        
        public virtual void MethodThree()
        {
            //Console.WriteLine("Method3");
        }

        public void InstanceMethod()
        {
        }

        public static void StaticMethod()
        {
            
        }
    }
    internal class Program
    {
        private static void Main()
        {
            var mc = new CustomClass();
            IInterfaceOne mi1 = mc;
            IInterfaceTwo mi2 = mc;

            mc.MethodThree();
            mi1.MethodOne();
            mi2.MethodTwo();


            int i = CustomClass.str.Length;
            uint j = CustomClass.ui;

            mc.InstanceMethod();
            CustomClass.StaticMethod();
            mc.MethodOne();
            mc.MethodThree();
            mi1.MethodOne();
            mi1.MethodTwo();
            mi2.MethodTwo();
            mi2.MethodTwo();
            mc.ToString();
        }
    }
}