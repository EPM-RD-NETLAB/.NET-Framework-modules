﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sample2
{
    public class BaseClass
    {
        public void InstanceMethod() { }
        public virtual void InstanceVirtualMethod() { }
        public virtual void InstanceVirtualMethodOne() { }
        public virtual void InstanceVirtualMethodThree() { }
        public static void StaticMethod() { }
    }

    public class DerivedClass : BaseClass
    {
        public override void InstanceVirtualMethod() { }
        public override void InstanceVirtualMethodOne() { }
        public override string ToString()
        {
            return string.Empty;
        }
    }

    public class DerivedClassAgain : BaseClass, ICloneable
    {
        public override void InstanceVirtualMethod() { }
        public override void InstanceVirtualMethodOne() { }
        public override string ToString()
        {
            return string.Empty;
        }

        public object Clone()
        {
            throw new NotImplementedException();
        }
    }

    struct Point
    {
        private int x, y;
    }
    class Program
    {
        static void Main(string[] args)
        {
            BaseClass derObj = new DerivedClass();
            var basObj = new BaseClass();
            basObj.ToString();
            BaseClass derObj1 = new DerivedClass();
            DerivedClassAgain derObj2 = new DerivedClassAgain();
            ICloneable ic = derObj2;
            derObj.InstanceMethod();
            derObj1.InstanceMethod();
            derObj.InstanceVirtualMethod();
            derObj2.InstanceVirtualMethod();
            derObj.InstanceVirtualMethodOne();
            derObj2.Clone();
            ic.Clone();
            BaseClass.StaticMethod();
            Point p = default(Point);
            p.GetHashCode();
            p.ToString();
        }
    }
}
